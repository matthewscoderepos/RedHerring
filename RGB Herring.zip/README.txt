# # # # # # # # # # # # #
#	RGB Herring	#
# 			#
# by: the pixel bandits #
# # # # # # # # # # # # #

to use RGB Herring:

	1.run the included Mars jar.
	2.open main.asm
	3.make sure all other asm files are in the same directory
	4.compile and run main, RGB Herring should now be running

notes:
	a.bmp is a sample image guaranteed to work for encoding/decoding
	otherwise follow all prompts to ensure no errors.